<?php

namespace Laravel\Horizon\Events;

class JobReserved extends RedisEvent
{
    //
}
