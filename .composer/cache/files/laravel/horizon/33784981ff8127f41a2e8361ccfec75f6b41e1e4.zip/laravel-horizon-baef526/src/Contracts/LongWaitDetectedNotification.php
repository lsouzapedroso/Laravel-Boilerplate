<?php

namespace Laravel\Horizon\Contracts;

interface LongWaitDetectedNotification
{
    //
}
